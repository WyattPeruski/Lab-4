import java.util.Formatter;
import java.util.Scanner;
public class lab_4 {
  public static void main(String args[]) {
    Formatter fmt;
    int y = 1;
    boolean Continue;
    while(y==1) {
    Scanner St = new Scanner(System.in);
    System.out.printf("Time to learn squares and cubes! Enter an integer: ");
    int number = St.nextInt();

   for(int i = 1; i <= number; i++) {
      fmt = new Formatter();

      fmt.format("%4d %4d %4d", i, i * i, i * i * i);
      System.out.println(fmt);
    }
   Scanner scnr = new Scanner(System.in);
   System.out.printf("Do you want another set: ");
   Continue = scnr.next().startsWith("y");
   if(Continue == true) {
	   y = 1;
   }
   else {
	   y = 2;
   }
  }
}
}